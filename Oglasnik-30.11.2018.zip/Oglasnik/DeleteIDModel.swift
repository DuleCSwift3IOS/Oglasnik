//
//  DeleteIDModel.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 1/18/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import Foundation
import ObjectMapper
class DeleteIDModel : Mappable
{
  var email: String?
  var password: String?
  var adID: String?
  required init?(map: Map) {
    
  }
   
  func mapping(map: Map) {
    email <- map["user_email"]
    password <- map["password"]
    adID <- map["id"]
  }
  
  
  
}
