//
//  LeftViewController.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 2/7/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import UIKit

class LeftViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
  var appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
  @IBOutlet weak var navTableView: UITableView!
  var menuItems = [Dictionary<String,String>]()
  var newMenuItem = [Dictionary<String, String>]()
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if section == 0
    {
    return menuItems.count
    }
    return newMenuItem.count
  }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
  self.navigationController?.view.layoutSubviews()
    updateArrayMenuOptions()
    //addNewMenuIremInSecoundSection()
  }
  
  func updateArrayMenuOptions()
  {
    menuItems.removeAll()
    menuItems.append(["title": "Home", "icon":"home_icon"])
    menuItems.append(["title": "Publish Ad","icon":"add_icon"])
    menuItems.append(["title": "All Ads", "icon": "icons8-list"])
    menuItems.append(["title": "Events", "icon": "event_calendar"])
    menuItems.append(["title": "My Ads", "icon":""])
    menuItems.append(["title":"Favorite Ads", "icon":""])
    menuItems.append(["title": "Options", "icon":"options_icon"])
    menuItems.append(["title":"Contact Us","icon":""])
    menuItems.append(["title": "Login", "icon": "login_icon"])
    menuItems.append(["title": "Registration", "icon": "user_registration"])
    navTableView.reloadData()
  }
  
//  func addNewMenuIremInSecoundSection()
//  {
//    newMenuItem.removeAll()
//    newMenuItem.append(["title": "Options", "icon": "options_icon"])
//  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let myCell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! LeftSideNavTableViewCell
    if indexPath.section == 0
    {
    myCell.leftSideImageView.image = UIImage(named: menuItems[indexPath.row]["icon"]!)
    myCell.leftSideLabel.text = menuItems[indexPath.row]["title"]
    }
    else
    {
    myCell.leftSideImageView.image = UIImage(named: newMenuItem[indexPath.row]["icon"]!)
    myCell.leftSideLabel.text = newMenuItem[indexPath.row]["title"]
    }
    return myCell
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    switch (indexPath.row) {
    case 0:
      let menuViewController = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
      let menuNavController = UINavigationController(rootViewController: menuViewController)
      appDelegate.centerContainer?.centerViewController = menuNavController
      appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
      break;
    case 1:
      let publishAdViewController = self.storyboard?.instantiateViewController(withIdentifier: "AddNewAdsViewController") as! AddNewAdsViewController
      let addAdNavController = UINavigationController(rootViewController: publishAdViewController)
      appDelegate.centerContainer?.centerViewController = addAdNavController
      appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
      break;
    case 2:
        if UserDefaults.standard.bool(forKey: "isLoggedIn") == false
        {
          //print("You are logged in")
          let listAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
          let listAdsNavController = UINavigationController(rootViewController: listAdsViewController)
          appDelegate.centerContainer?.centerViewController = listAdsNavController
          appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
        }
        else
        {
//          let loginViewController = self.storyboard?.instantiateViewController(withIdentifier: "LoginFormViewController") as! LoginFormViewController
//          let loginNavController = UINavigationController(rootViewController: loginViewController)
//          appDelegate.centerContainer?.centerViewController = loginNavController
//          appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
          let listAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
          let listAdsNavController = UINavigationController(rootViewController: listAdsViewController)
          appDelegate.centerContainer?.centerViewController = listAdsNavController
          appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
        }
      break
    case 3:
      let eventsViewController = self.storyboard?.instantiateViewController(withIdentifier: "EventsViewController") as! EventsViewController
      let eventsNavController = UINavigationController(rootViewController: eventsViewController)
      appDelegate.centerContainer?.centerViewController = eventsNavController
      appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
      break
    case 4:
      let myAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "MyAdsViewContoller") as! MyAdsViewController
      
      let myAdsNavController = UINavigationController(rootViewController: myAdsViewController)
      
      appDelegate.centerContainer?.centerViewController = myAdsNavController
      
      appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
      break
    case 5:
      if UserDefaults.standard.bool(forKey: "isLoggedIn") == true
      {
      let favoriteAdsTableViewController = self.storyboard?.instantiateViewController(withIdentifier: "FavoriteAdsTableViewController") as! FavoriteAdsTableViewController
      let favoriteNavTableViewController = UINavigationController(rootViewController: favoriteAdsTableViewController)
      
      appDelegate.centerContainer?.centerViewController = favoriteNavTableViewController
      appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
      }
      else
      {
        let loginViewController = self.storyboard?.instantiateViewController(withIdentifier: "LoginFormViewController") as! LoginFormViewController
        let loginNavController = UINavigationController(rootViewController: loginViewController)
        appDelegate.centerContainer?.centerViewController = loginNavController
        appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
      }
      
      break
    case 6:
      let myPfrofileOptionViewController = self.storyboard?.instantiateViewController(withIdentifier: "MyProfileTableViewController") as! MyProfileTableViewController
      let myProfileNavController = UINavigationController(rootViewController: myPfrofileOptionViewController)
      appDelegate.centerContainer?.centerViewController = myProfileNavController
      appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
      break
    case 7:
      let contactUsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ContactUsViewController") as! ContactUsViewController
      let contactUsNavController = UINavigationController(rootViewController: contactUsViewController)
      appDelegate.centerContainer?.centerViewController = contactUsNavController
      appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
      break
    case 8:
      let loginViewController = self.storyboard?.instantiateViewController(withIdentifier: "LoginFormViewController") as! LoginFormViewController
      let loginNavController = UINavigationController(rootViewController: loginViewController)
      appDelegate.centerContainer?.centerViewController = loginNavController
      appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
      break
    case 9:
      let registrationViewController = self.storyboard?.instantiateViewController(withIdentifier: "RegistrationFormViewController") as! RegistrationFormViewController
      let registrationNavController = UINavigationController(rootViewController: registrationViewController)
      appDelegate.centerContainer?.centerViewController = registrationNavController
      appDelegate.centerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
      break
    default:
      print("\(menuItems[indexPath.row]) is selected")
    }
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    // Do any additional setup after loading the view.
  }
  
  func numberOfSections(in tableView: UITableView) -> Int {
    return 2;
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
