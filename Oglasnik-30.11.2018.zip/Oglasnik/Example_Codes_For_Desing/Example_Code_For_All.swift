//
//  Example_Code_For_All.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 7/26/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import Foundation
/*
 // the following code increases cell border only on specified borders
 let bottom_border = CALayer()
 let bottom_padding = CGFloat(10.0)
 bottom_border.borderColor = UIColor.white.cgColor
 bottom_border.frame = CGRect(x: 0, y: cell.frame.size.height - bottom_padding, width:  cell.frame.size.width, height: cell.frame.size.height)
 bottom_border.borderWidth = bottom_padding
 
 let right_border = CALayer()
 let right_padding = CGFloat(15.0)
 right_border.borderColor = UIColor.white.cgColor
 right_border.frame = CGRect(x: cell.frame.size.width - right_padding, y: 0, width: right_padding, height: cell.frame.size.height)
 right_border.borderWidth = right_padding
 
 let left_border = CALayer()
 let left_padding = CGFloat(15.0)
 left_border.borderColor = UIColor.white.cgColor
 left_border.frame = CGRect(x: 0, y: 0, width: left_padding, height: cell.frame.size.height)
 left_border.borderWidth = left_padding
 
 let top_border = CALayer()
 let top_padding = CGFloat(10.0)
 top_border.borderColor = UIColor.white.cgColor
 top_border.frame = CGRect(x: 0, y: 0, width: cell.frame.size.width, height: top_padding)
 top_border.borderWidth = top_padding
 
 
 cell.layer.addSublayer(bottom_border)
 cell.layer.addSublayer(right_border)
 cell.layer.addSublayer(left_border)
 cell.layer.addSublayer(top_border)
 */
extension UIImage{
  
//  func resizeImageWith(newSize: CGSize) -> UIImage {
//
//    let horizontalRatio = newSize.width / size.width
//    let verticalRatio = newSize.height / size.height
//
//    let ratio = max(horizontalRatio, verticalRatio)
//    let newSize = CGSize(width: size.width * ratio, height: size.height * ratio)
//    UIGraphicsBeginImageContextWithOptions(newSize, true, 0)
//    draw(in: CGRect(origin: CGPoint(x: 0, y: 0), size: newSize))
//    let newImage = UIGraphicsGetImageFromCurrentImageContext()
//    UIGraphicsEndImageContext()
//    return newImage!
//  }
  func resizeImage(image: UIImage, newWidth: CGFloat) -> UIImage {
    
    let scale = newWidth / image.size.width
    let newHeight = image.size.height * scale
    UIGraphicsBeginImageContext(CGSize(width: newWidth, height: newHeight))//CGSizeMake(newWidth, newHeight))
    image.draw(in: CGRect(x: 0, y: 0, width: newWidth, height: newHeight) )//CGRectMake(0, 0, newWidth, newHeight))
    let newImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    return newImage!
  }
}
extension UILabel{
  func setCornerRadiusbutton() {
    self.layer.cornerRadius = self.frame.size.height / 2
    self.clipsToBounds = true
    
  }
}
extension UIImageView{
  func setCornerRadiusImageView() {
    self.layer.cornerRadius = self.frame.size.height / 8
    self.clipsToBounds = true
    
  }
}
extension UIStackView{
  func setCornerRadiusStackView() {
    self.layer.cornerRadius = self.frame.size.height / 2
    self.clipsToBounds = true
    
  }
}
