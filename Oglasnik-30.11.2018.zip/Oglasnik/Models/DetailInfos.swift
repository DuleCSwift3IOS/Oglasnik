//
//  DetailInfos.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 8/7/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import Foundation
import ObjectMapper
struct DetailInfos: Mappable {
  var id_Ad: String?
 // var category_id : String?
  var categoryName: String?
  var adTypeName: String?
  var brandModelName: String?
  var modelName: String?
  var brandName: String?
  var fuelName: String?
  var colorName: String?
  var consumptionInL : String?
  var yearOfProductName: String?
  var spentMails: String?
  var gearBox: String?
  var areaName : String?
  var numberOfRooms : String?
  var floor: String?
 // var settlement: String?
  var numberOfFloors: String?
  var local : String?
  var location_name : String?
  var begin: String?
  var end: String?
  var fbEvent: String?
  var price: String?
  var valute: String?
  var description: String?
 // var quality: String?
//  var old_New : String?
  var region: String?
  var video : String?
  var fullName: String?
  var phoneNumber: String?
  var userEmail: String?
  var userFB: String?
  var titleOfAdvertisment : String?
  var date_update: String?
  var expired : String?
  var favorite : String?
  var images : [String]?
  init?(map: Map) {
    
  }
  
  mutating func mapping(map: Map) {
    id_Ad <- map["id"]
    //category_id <- map[""]
    titleOfAdvertisment <- map["title"]
    categoryName <- map ["category_name"]
    adTypeName <- map["ad_type"]
    brandModelName <- map["model"]
    brandName <- map["make"]
    modelName <- map["model"]
    fuelName <- map["fuel_type"]
    colorName <- map["color"]
    date_update <- map["date_updated"]
    consumptionInL <- map["fuel_consumption"]
    yearOfProductName <- map["year"]
    spentMails <- map["kilometers"]
    gearBox <- map["transmission"]
    areaName <- map["square"]
    numberOfRooms <- map["rooms"]
    floor <- map["floors"]
    //settlement <- map[""]
    numberOfFloors <- map["floor_no"]
    local <- map["local"]
    location_name <- map["location_name"]
    begin <- map["event_start"]
    end <- map["event_end"]
    fbEvent <- map["fb_event_id"]
    price <- map["price"]
    valute <- map["currency"]
    description <- map["description"]
   // quality <- map[""]
   // old_New <- map[""]
    region <- map["location_name"]
    video <- map["video"]
    fullName <- map["name"]
    phoneNumber <- map["phone"]
    userEmail <- map["email"]
    userFB <- map["fbLink"]
    expired <- map["expired"]
    favorite <- map["favorite"]
    images <- map["images"]
  }
  
  
}
