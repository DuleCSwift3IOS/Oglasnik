//
//  CategoryModelsPickerView.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 7/18/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import Foundation
import ObjectMapper
class CategoryModels: Mappable
{
  var make_Model: String?
  var model_id: String?
  
  required init?(map: Map) {
  }
  
  func mapping(map: Map) {
    make_Model <- map["make_model"]
    model_id <- map["id"]
  }
}
