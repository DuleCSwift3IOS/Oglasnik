//
//  UserProfile.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 11/4/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import Foundation
import ObjectMapper
struct UserProfile : Mappable
{
  //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=change_profile
  
  //POST email, password, firstname, location, telefon
  var id: String?
  var email: String?
  var password: String?
  var firstName: String?
  var location: String?
  var telefon: String?
  var verified: String?
  var last_login: String?
  init?(map: Map) {
    
  }
  mutating func mapping(map: Map) {
    id <- map["id"]
    email <- map["email"]
    password <- map["password"]
    firstName <- map["firstname"]
    location <- map["location"]
    verified <- map["verified"]
    last_login <- map["last_login"]
  }
}
