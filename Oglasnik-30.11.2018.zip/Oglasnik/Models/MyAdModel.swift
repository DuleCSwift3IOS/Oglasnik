//
//  MyAdModel.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 10/24/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import Foundation
import ObjectMapper
struct MyAdModel: Mappable
{
  var myAds: [ListMyAds]?
  init?(map: Map) {
    
  }
  mutating func mapping(map: Map) {
    myAds <- map["data"]
  }
}
struct ListMyAds: Mappable
{
  var category_id: String?
  var category_name: String?
  var currency: String?
  var date_posted: String?
  var date_updated: String?
  var event_start: String?
  var favorite: String?
  var id: String?
  var images: [String]?
  var local: String?
  var location_name: String?
  var price: String?
  var title: String?
  var views: String?
  var vip: String?
  var unFavorite:String?
  init(unFavorite: String) {
    self.unFavorite = unFavorite
  }
  
  init?(map: Map) {
    
  }
   mutating func mapping(map: Map) {
    category_id <- map["category_id"]
    category_name <- map["category_name"]
    currency <- map["currency"]
    date_posted <- map["date_posted"]
    date_updated <- map["date_updated"]
    event_start <- map["event_start"]
    favorite <- map["favorite"]
    id <- map["id"]
    images <- map["images"]
    local <- map["local"]
    location_name <- map["location_name"]
    price <- map["price"]
    title <- map["title"]
    views <- map["views"]
    vip <- map["vip"]
  }
}
