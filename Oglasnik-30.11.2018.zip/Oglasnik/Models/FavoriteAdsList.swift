//
//  FavoriteAdsList.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 10/12/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import Foundation
import ObjectMapper
struct FavoritesAds: Mappable
{
  
  var favoteDataAds: [ListFavoriteAds]?
  init?(map: Map)
  {
    
  }
  
  mutating func mapping(map: Map)
  {
    favoteDataAds <- map["data"]
  }
}
struct ListFavoriteAds: Mappable {
  var category_name: String?
    var currency: String?
    var price: String?
    var date_posted: String?
    var id: String?
    var images: [String]?
    var favorite: String?
  var title: String?
  var views: String?
  init?(map: Map)
  {
    
  }
  
  mutating func mapping(map: Map)
  {
    category_name <- map["category_name"]
    currency <- map["currency"]
    price <- map["price"]
    date_posted <- map["date_posted"]
    id <- map["id"]
    images <- map["images"]
    favorite <- map["favorite"]
    views <- map["views"]
    title <- map["title"]
  }
}

  
//  required init?(map: Map) {
//  }
//  func mapping(map: Map) {
//    category_name <- map["category_name"]

//  }
//}

