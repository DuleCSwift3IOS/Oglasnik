//
//  CategoryNamesPickerView.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 7/18/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import Foundation
import ObjectMapper
class ListCategories: Mappable
{
  var category_name: String?
  var category_id: String?
  var emptyString: [String]?
  var parent_id: String?
  
  required init?(map: Map) {
  }
  
  func mapping(map: Map) {
    category_id <- map["id"]
    category_name <- map["category_name"]
    parent_id <- map["parent_id"]
  }
  
  
  
}
