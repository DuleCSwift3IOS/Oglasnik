//
//  DetailModelImages.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 7/31/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import Foundation
import ObjectMapper
//class DetailModelImages : Mappable
//{
//  required init?(map: Map) {
//    <#code#>
//  }
//  
//  func mapping(map: Map) {
//    <#code#>
//  }
//  
//  
//}

