//
//  Locations.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 7/18/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import Foundation
import ObjectMapper
class Locations: Mappable
{
  var location_id: String?
  var location_name: String?
  
  required init?(map: Map) {
    
  }
  
  func mapping(map: Map) {
    location_id <- map["id"]
    location_name <- map["location"]
  }
  
  
}
