//
//  LoginFormViewController.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 11/25/17.
//  Copyright © 2017 Big Nerd Ranch. All rights reserved.
//

import UIKit
import PasswordTextField
import Alamofire
class LoginFormViewController: UIViewController {

  @IBAction func leftSideMenuButtonTapped(_ sender: Any) {
    
    var isLogOut = UserDefaults.standard.bool(forKey: "isLoggedIn")
    if isLogOut == false
    {
    let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
    appDelegate.centerContainer!.toggle(MMDrawerSide.left, animated: true, completion: nil)
    }
    else
    {
      let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
      appDelegate.centerContainer!.toggle(MMDrawerSide.left, animated: true, completion: nil)
    }
    
  }
  
  @IBOutlet weak var errorLabel: UILabel!
  @IBOutlet weak var usernameTF: UITextField!
  @IBOutlet weak var passwordTF: PasswordTextField!
  var showUserID: Any?
  var timer = Timer()
  
  let delay = 5.0
  var userName: String? = ""
  var userPassword: String? = ""
  let defaultValues = UserDefaults.standard
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }
  override func viewDidLoad() {
    super.viewDidLoad()
    usernameTF.AddImage(direction: .Left, imageName: "user_registration", Frame: CGRect(x: 0, y: 0, width: 40.0, height: 40.0), backgroundColor: .clear)
    passwordTF.AddImage(direction: .Left, imageName: "user_pass", Frame: CGRect(x: 0, y: 0, width: 40.0, height: 40.0), backgroundColor: .clear)
    //self.navigationController?.navigationItem.hidesBackButton = false
    //hiding the navigation button
//    let backButton = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: navigationController, action: nil)
//    navigationItem.leftBarButtonItem = backButton
    
    // Do any additional setup after loading the view, typically from a nib.
    
    //if user is already logged in switching to profile screen
//    var showFirstName = defaultValues.string(forKey: "firstname")
//    print(showFirstName)
//    if defaultValues.string(forKey: "firstname") != nil{
//      let profileViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
//      self.navigationController?.pushViewController(profileViewController, animated: true)
//
//    }
    usernameTF.text = userName
    passwordTF.text = userPassword
  }
  @objc func backSelf() -> String {
    //after 10 secounds thay go back to own rootviewcontoller  or LoginViewController
    //self.navigationController?.popViewController(animated: true)
    //self.dismiss(animated: true, completion: nil)
    errorLabel.backgroundColor = UIColor.clear
    errorLabel.text = ""
    return errorLabel.text!
  }
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    usernameTF.text = ""
    passwordTF.text = ""
    self.navigationController?.navigationItem.backBarButtonItem?.title = ""
  }
  @IBAction func pressLoginButton(_ sender: Any) {
    
    let validationRule = RegexRule(regex:"^[A-Z ]+$", errorMessage: "Password must contain only uppercase letters")
    
    self.passwordTF.validationRule = validationRule
    //passwordTextField.validationRule = validationRule
    
    if self.passwordTF.isInvalid(){
      print(self.passwordTF.errorMessage)
    }
    
    let email : String = self.usernameTF.text!
    let password : String = self.passwordTF.text!
    
    
    
    let URL_USER_LOGIN = "https://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=login"
    
    //getting the username and password
    let parameters: Parameters=[
      "email":email,
      "password":password
    ]
    print(email)
    print(password)
    //making a post request
    Alamofire.request(URL_USER_LOGIN, method: .post, parameters: parameters).responseJSON
      {
    response in
    //printing response
    print(response)
    //getting the json value from the server
    if let result = response.result.value {
    let jsonData = result as! NSDictionary
    //if there is no error
  //  print(jsonData.value(forKey: "success")!)
      let getTrue = 1
      let error = jsonData.value(forKey: "success")
      self.defaultValues.set(error, forKey: "success")
      let getSuccess = error as? Int
    if (getSuccess == getTrue) {
    //getting the user from response
      let user = jsonData.value(forKey: "user") as! NSDictionary
      //getting user values
      let userName = user.value(forKey: "firstname") as! String
      //let userPass = user.value(forKey: "password") as! String
      let userEmail = user.value(forKey: "email") as! String
      let userPhone = user.value(forKey: "telefon") as! String
      let userID = user.value(forKey: "id")
      //saving user values to defaults
     // print(userName)
      var setPassDefaultVal = self.defaultValues.set(password, forKey: "password")
      var setUserID = self.defaultValues.set(userID, forKey: "id")
      print(self.defaultValues.value(forKey: "id")!)
      UserDefaults.standard.set(userEmail, forKey: "email")
      UserDefaults.standard.set(self.passwordTF.text, forKey: "password")
      var showUserName = self.defaultValues.set(userName, forKey: "username")
      var showUserEmail = self.defaultValues.set(userEmail, forKey:"email")
      var showUserPhone = self.defaultValues.setValue(userPhone, forKey: "phone")
      //var showUserPass = self.defaultValues.set(userPass, forKey: "password")
      //var showUserID = self.defaultValues.set(userID, forKey: "id")
      self.showUserID = userID
      //print(self.defaultValues.string(forKey: "username")!)
      //print(userPass)
      /*
       let dict:[String:String] = ["key":"Hello"]
       UserDefaults.standard.set(dict, forKey: "dict")
       let result = UserDefaults.standard.value(forKey: "dict")
       print(result!)
       // Output -> { key:hello;}
       */
      
      var showFirstName = self.defaultValues.string(forKey: "username")!
     // print(showFirstName)
      if showFirstName != nil{
        let profileViewController = self.storyboard?.instantiateViewController(withIdentifier: "GoToTabBarController") as! UITabBarController //UISplitViewController
      //  self.navigationController?.pushViewController(profileViewController, animated: true)
        
        self.present(profileViewController, animated: true)
        UserDefaults.standard.set("true", forKey: "isLoggedIn")
        UserDefaults.standard.synchronize()
        
      }
      
      //switching the screen
//      let profileViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
//      self.navigationController?.pushViewController(profileViewController, animated: true)
//
//      self.dismiss(animated: false, completion: nil)
    }
//    else{
//      //error message in case of invalid credential
//      self.errorLabel.text = jsonData.object(forKey: "message") as? String
//    }
    else
    {
      self.errorLabel.backgroundColor = UIColor.red
      self.errorLabel.textColor = UIColor.white
      self.errorLabel.text = jsonData.value(forKey: "message") as? String
      print(self.errorLabel.text)
     // self.navigationController?.popViewController(animated: true)
//      UserDefaults.standard.set(false, forKey: "isLoggedIn")
//      UserDefaults.standard.synchronize()
      self.timer.invalidate()
      // start the timer
      self.timer = Timer.scheduledTimer(timeInterval: self.delay, target: self, selector: #selector(self.backSelf), userInfo: nil, repeats: false)
    //  var window: UIWindow?
    //  let rootTabController = window?.rootViewController as? UITabBarController
      //if rootTabController?.selectedIndex == 1
      //{
      //self.present(rootTabController!, animated: true)
      //}
      //self.dismiss(animated: true, completion: nil)
//      UserDefaults.standard.set(false, forKey: "isLoggedIn")
//      UserDefaults.standard.synchronize()
    }
  }
    
}
    /*
     //making a post request
     Alamofire.request(URL_USER_LOGIN, method: .post, parameters: parameters).responseJSON
     {
     response in
     //printing response
     print(response)
     
     //getting the json value from the server
     if let result = response.result.value {
     let jsonData = result as! NSDictionary
     
     //if there is no error
     print(jsonData.value(forKey: "success")!)
     let getTrue = 1
     let error = jsonData.value(forKey: "success")
     let getSuccess = error as! Int
     if (getSuccess == getTrue) {
     
     //getting the user from response
     let user = jsonData.value(forKey: "user") as! NSDictionary
     
     //getting user values
     let userName = user.value(forKey: "firstname") as! String
     let userEmail = user.value(forKey: "email") as! String
     
     //saving user values to defaults
     var showUserName = self.defaultValues.set(userName, forKey: "username")
     var showUserEmail = self.defaultValues.set(userEmail, forKey:"email")
     
     print(showUserName)
     /*
     let dict:[String:String] = ["key":"Hello"]
     UserDefaults.standard.set(dict, forKey: "dict")
     let result = UserDefaults.standard.value(forKey: "dict")
     print(result!)
     // Output -> { key:hello;}
     */
     
     //switching the screen
     //  let profileViewController =
     let profileViewController = self.storyboard?.instantiateViewController(withIdentifier: "LoggedPersonViewController") as! LoggedPersonViewController
     self.navigationController?.pushViewController(profileViewController, animated: true)
     
     self.dismiss(animated: false, completion: nil)
     }else{
     //error message in case of invalid credential
     self.labelMessage.text = jsonData.object(forKey: "message") as? String
     }
     }
     }
     */
}
  
  
  @IBAction func checkIfIsGuest(_ sender: Any) {
    self.dismiss(animated: true, completion: nil)
    UserDefaults.standard.set(false
      , forKey: "isLoggedIn")
    UserDefaults.standard.synchronize()
  }
  
}
