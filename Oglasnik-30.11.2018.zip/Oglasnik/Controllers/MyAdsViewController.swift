//
//  MyAdsViewController.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 10/15/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import UIKit
import Alamofire
class MyAdsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
  
  var userDefault = UserDefaults.standard
  @IBAction func backToMenuListAction(_ sender: Any) {
  var appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
    appDelegate.centerContainer!.toggle(MMDrawerSide.left, animated: true, completion: nil)
  }
  var editTagId: Int = 0
  var editButton = UIButton()
  var myAdCells: MyAdsCell?
  var myAdModelArray = [ListMyAds]()
  var selectedRows: [IndexPath] = []
  var valueToPass : String?
  override func viewDidLoad() {
    super.viewDidLoad()
    /*UserDefaults.value(forKey: "email")!, userDefailt.value(forKey: "password")! */
    
    weak var weakSelf = self
    let URL_MYADS_API = URL(string:"https://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=listMyAds")
    let parameters: Parameters = ["email": userDefault.string(forKey: "email")!,"password": userDefault.string(forKey: "password")!]
        //userDefailt.synchronize()
    Alamofire.request(URL_MYADS_API!, method: .post, parameters: parameters as [String: AnyObject]).responseObject { (response: DataResponse<MyAdModel>) in
      let responseAnswer = response.result.value
 
      weakSelf?.myAdModelArray = (responseAnswer?.myAds)!
//      self.myAdCells?.editButton.addTarget(self, action: #selector(self.editMyAd(_ :)), for: .touchUpInside)
  
      self.myAdsTableView.reloadData()
    }
//myAdCells?.editButton.addTarget(self, action: #selector(self.editMyAd(sender :)), for: .touchUpInside)
    
    //self.editMyAd(sender: editButton)
  }
 
//  @objc func editMyAd(sender: UIButton)
//  {
//   // for (index, value) in myAdModelArray
//   // {
//
//    //editTagId = sender.tag
//    print("tag button",sender.tag)
//      performSegue(withIdentifier: "showMyAdEdit", sender: self)
//  //  }
//  }
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    print("segue identifier",segue.identifier)
    if segue.identifier == "showMyAdEdit"
    {

//      if let destionationAdNewAdViewController = segue.destination as? AddNewAdsViewController
//      {
//              print("print here adEditId!", "\(self.editButton.tag)")
//        destionationAdNewAdViewController.editAdId = String("\(self.editButton.tag)")
//      }
      
      let destinationAdNewAdViewController = segue.destination as! AddNewAdsViewController
      
      destinationAdNewAdViewController.editAdId = String("\(self.editButton.tag)")
      self.myAdsTableView.reloadData()
//      let destionationAdNewAdViewContorller = segue.destination as! AddNewAdsViewController
//      print("print here adEditId!", "\(self.editButton.tag)")
//      destionationAdNewAdViewContorller.editAdId = String("\(self.editButton.tag)") //(self.userDefault.string(forKey: "editAdId"))!
      let indexPath = self.myAdsTableView.indexPathForSelectedRow
      //myAdsTableView.deselectRow(at: indexPath!, animated: true)
    }
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return myAdModelArray.count
  }
  
  
   func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let myAdCell = tableView.dequeueReusableCell(withIdentifier: "myAdsCell", for: indexPath) as! MyAdsCell
//myAdCell.myAdImageView.setCornerRadiusImageView()
//    myAdCell.myAdInfoStackView.setCornerRadiusStackView()
//myAdCell.myAdPublishedLabel.setCornerRadiusbutton()
//myAdCell.myAdTitleLabel.setCornerRadiusbutton()
//myAdCell.myAdPublishDateLabel.setCornerRadiusbutton()
//myAdCell.myAdPriceLabel.setCornerRadiusbutton()
//myAdCell.myAdPriceAndValuteLabel.setCornerRadiusbutton()
//myAdCell.myAdViewLabel.setCornerRadiusbutton()
//myAdCell.myAdNumberOfViewLabel.setCornerRadiusbutton()
    if (myAdModelArray[indexPath.row].images?.first?.isEmpty)!
    {
      myAdCell.myAdImageView.image = UIImage(named: "no_camera")
    }
    else {
    myAdCell.myAdImageView.image = UIImage(named: (myAdModelArray[indexPath.row].images?.first)!)
    }
      
      
      
      
      
    myAdCell.myAdTitleLabel.text = myAdModelArray[indexPath.row].title
    let dateFormatterPublishedOn = DateFormatter()
    dateFormatterPublishedOn.dateFormat = "yyyy-MM-dd HH:mm:ss"
    let datePublishedOn = dateFormatterPublishedOn.date(from: (myAdModelArray[indexPath.row].date_updated)!)
    dateFormatterPublishedOn.dateFormat = "dd.MM.YYYY"
    let newFormatPublishOn = dateFormatterPublishedOn.string(from: datePublishedOn!)
    myAdCell.myAdPublishDateLabel.text = newFormatPublishOn
    myAdCell.myAdPriceAndValuteLabel.text = myAdModelArray[indexPath.row].price! + " " + myAdModelArray[indexPath.row].currency!
    myAdCell.myAdNumberOfViewLabel.text = myAdModelArray[indexPath.row].views
    
    //selectedRows.contains(indexPath)
    //myAdModelArray[indexPath.row].unFavorite! += "0"
    //print("Favorite",myAdModelArray[indexPath.row].unFavorite!)
    if myAdModelArray[indexPath.row].favorite == "1"
    {
    myAdCell.checkedAndUnCheckedButton.setImage(UIImage(named: "checked-checkbox-filled"), for: .normal)
     // myAdModelArray[indexPath.row].favorite = "0"
    }
    else
    {
//    if myAdModelArray[indexPath.row].unFavorite == "0" || !selectedRows.contains(indexPath)
//    {
      myAdCell.checkedAndUnCheckedButton.setImage(UIImage(named: "unchecked-checkbox-color"), for: .normal)
     // var unFavorite = ListMyAds.init(unFavorite: "0")
       // unFavorite.unFavorite?.append("1")
    }
    print("print cheked tag button",myAdCell.checkedAndUnCheckedButton.tag)
    myAdCell.checkedAndUnCheckedButton.tag = indexPath.row
    myAdCell.checkedAndUnCheckedButton.addTarget(self, action: #selector(checkedAndUnCheckedButtonAction(_:)), for: .touchUpInside)
    //MARK- : set tag to have value from model of Ad
    print("edit Ad Id", self.myAdModelArray[indexPath.row].id!)
    editButton.tag = Int(self.myAdModelArray[indexPath.row].id!)!
    myAdCell.editButton.tag = Int(myAdModelArray[indexPath.row].id!)!
    //self.editButton.tag = myAdCell.editButton.tag
    
    return myAdCell
  }
  
  /*
   func tableView(tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath!) {
   println("You selected cell #\(indexPath.row)!")
   
   // Get Cell Label
   let indexPath = tableView.indexPathForSelectedRow();
   let currentCell = tableView.cellForRowAtIndexPath(indexPath!) as UITableViewCell!;
   
   valueToPass = currentCell.textLabel.text
   performSegueWithIdentifier("yourSegueIdentifer", sender: self)
   
   }
   */
//  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//    let indexPathOfCell = self.myAdsTableView.indexPathForSelectedRow
//    let currentSelectedCell = self.myAdsTableView.cellForRow(at: indexPathOfCell!) as! MyAdsCell
//    valueToPass = self.myAdModelArray[(indexPathOfCell?.row)!].id!
//    performSegue(withIdentifier: "", sender: self)
//  }
  
  @objc func checkedAndUnCheckedButtonAction(_ sender: UIButton) {
    
    var selectedIndexPath = IndexPath(row: sender.tag, section: 0)
    print("selectedIndexPath",selectedIndexPath)
    
    
    if myAdModelArray[selectedIndexPath.row].favorite == "0"
    {
      myAdModelArray[selectedIndexPath.row].favorite = "1"
      sender.setImage(UIImage(named: "checked-checkbox-filled"), for: .normal)
      sender.tag = Int(self.myAdModelArray[selectedIndexPath.row].id!)!
      //myAdCell.checkedAndUnCheckedButton.setImage(UIImage(named: "checked-checkbox-filled"), for: .normal)
      
    }
    else
    {
      
      myAdModelArray[selectedIndexPath.row].favorite = "0"
      sender.setImage(UIImage(named: "unchecked-checkbox-color"), for: .normal)
      //    if myAdModelArray[indexPath.row].unFavorite == "0" || !selectedRows.contains(indexPath)
      //    {
      //myAdCell.checkedAndUnCheckedButton.setImage(UIImage(named: "unchecked-checkbox-color"), for: .normal)
      // var unFavorite = ListMyAds.init(unFavorite: "0")
      // unFavorite.unFavorite?.append("1")
    
    }
    
    
    
//    if self.selectedRows.contains(selectedIndexPath)
//    {
//      self.selectedRows.remove(at: self.selectedRows.index(of: selectedIndexPath)!)
//    }
//    else
//    {
//      self.selectedRows.append(selectedIndexPath)
//    }
    
    /*
     if button.isSelected {
     button.setImage(UIImage(named: "filled-heart"), for: .normal)
     button.isSelected = false
     }else {
     button.setImage(UIImage(named: "empty-heart"), for: .selected)
     button.isSelected = true
     }
     */
    
    
    self.myAdsTableView.reloadData()
  }
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    editTagId = indexPath.row
    
    let selectedMessage = myAdModelArray[indexPath.row].id
    
    tableView.deselectRow(at: indexPath, animated: true)
    performSegue(withIdentifier: "showMyAdEdit", sender: selectedMessage)
  }
  @IBAction func selectAllCheckBoxAction(_ sender: UIButton) {
    //self.selectedRows = getAllIndexPaths()
    var s = ""
    
    if sender.currentTitle == "Select All"
    {
      s = "1"
      sender.setTitle("Deselect All", for: .normal)
      sender.contentEdgeInsets.right = 19
      sender.titleEdgeInsets.top = 20
      sender.imageEdgeInsets.left = 61
      sender.imageEdgeInsets.top = 5
      sender.imageEdgeInsets.bottom = 20
    }
    else
    {
      s = "0"
      sender.setTitle("Select All", for: .normal) 
    }
    for j in 0..<myAdModelArray.count
    {
      myAdModelArray[j].favorite! = s
    }
    self.myAdsTableView.reloadData()
  }
  
//  func getAllIndexPaths() -> [IndexPath]
//  {
//    var indexPaths: [IndexPath] = []
//    for j in 0..<myAdsTableView.numberOfRows(inSection: 0) {
//      if myAdsTableView.numberOfRows(inSection: 0) < 0
//      {
//        self.selectedRows.removeAll()
//      }
//      else
//      {
//        indexPaths.append(IndexPath(row:j, section: 0))
//      }
//    }
//    return indexPaths
//  }
  
  @IBAction func deleteAdsAction(_ sender: UIButton) {
    /*
     
     */
    
    
    /* Mark: - alert action with closure type
     alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
     print("Yay! You brought your towel!")
     }))
     --------------------------------------------------------------------------
     All Example with Alert action
     let alert = UIAlertController(title: "What's your name?", message: nil, preferredStyle: .alert)
     alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
     
     alert.addTextField(configurationHandler: { textField in
     textField.placeholder = "Input your name here..."
     })
     
     alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
     
     if let name = alert.textFields?.first?.text {
     print("Your name: \(name)")
     }
     }))
     
     self.present(alert, animated: true)
     
     
     */
    for index in 0..<self.myAdModelArray.count
    {
   // let confirmMSG = response!["message"]
    //telefonot i mailot od korisnikot
//    let attributString = NSMutableAttributedString(string: confirmMSG as! String, attributes: [NSAttributedStringKey.font : UIFont.systemFont(ofSize: 20), NSAttributedStringKey.foregroundColor: UIColor.green])
    let alertMessage = UIAlertController(title: "Delete MyAd", message: "Are you sure for delete\n \(self.myAdModelArray[index].title!)?", preferredStyle: .alert)
    alertMessage.addAction(UIAlertAction(title: "Yes", style: .cancel, handler: { action in
      
      
      let URL_API_UNFAVORITE = URL(string: "https://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=delete_ad&id="+(self.myAdModelArray[index].id)!)
         print("Print ID of Ad",(self.myAdModelArray[index].id)!,"email",self.userDefault.string(forKey: "email")!, "password", self.userDefault.string(forKey: "password")!)
      let parameters: Parameters = ["email": self.userDefault.string(forKey: "email")!, "password": self.userDefault.string(forKey: "password")!, "id": self.myAdModelArray[index].id!]
             // self.userDefailt.synchronize()
              Alamofire.request(URL_API_UNFAVORITE!, method: .post, parameters: parameters as [String: AnyObject]).responseJSON
                { (response) in
                  let responseAnswer = response
                  let response = response.result.value as? NSDictionary
                  print(response!["message"]!)
      
                  let errorAnswer = responseAnswer.result.error
                  if errorAnswer != nil
                  {
                    print(errorAnswer!)
                  }
                  else
                  {
                    
                  }
                  
                  self.myAdsTableView.reloadData()
      }
      self.myAdModelArray.remove(at: index)
    }))
    alertMessage.addAction(UIAlertAction(title: "No", style: .default, handler: { action in
      self.dismiss(animated: true, completion: nil)
    }))
      self.present(alertMessage, animated: true)
      
    }
    //              let alertMessage = UIAlertController(title: "", message: "", preferredStyle: .alert)
    //              alertMessage.setValue(attributString, forKey: "attributedTitle")
    //              self.present(alertMessage, animated: true, completion: nil)
    //self.alert(message: "Are You sure to delete \(self.myAdModelArray[index].title)", title: "\(self.myAdModelArray[index].title)")
    let when  = DispatchTime.now() + 4
    DispatchQueue.main.asyncAfter(deadline: when, execute: {
      //alert.dismiss(animated: true, completion: nil)
      //alert.accessibilityActivate()
    })
   
    
    
    //if !(self.selectedRows.isEmpty)
   // {
//      for index in 0..<myAdModelArray.count
//      {
//        let URL_API_UNFAVORITE = URL(string: "https://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=delete_ad&id="+(self.myAdModelArray[index].id)!)
//        let parameters: Parameters = ["email": userDefailt.string(forKey: "email")!, "password": userDefailt.string(forKey: "password")!]
//        userDefailt.synchronize()
//        Alamofire.request(URL_API_UNFAVORITE!, method: .post, parameters: parameters as [String: AnyObject]).responseJSON
//          { (response) in
//            let responseAnswer = response
//            let response = response.result.value as? NSDictionary
//            print(response!["message"]!)
//
//            let errorAnswer = responseAnswer.result.error
//            if errorAnswer != nil
//            {
//              print(errorAnswer!)
//            }
//            else
//            {
//
//            }
//        }
//        self.myAdModelArray.remove(at: index)
//      }
//      self.selectedRows.removeAll()
//      self.myAdsTableView.reloadData()
      //      self.performSegue(withIdentifier: "showDetailForFavoriteAd", sender: self)
      
 //   }
  }
  
  @IBAction func reNewAdDateAction(_ sender: UIButton) {
    for index in 0..<myAdModelArray.count
    {
      let API_URL_RENEW_AD = URL(string: "https://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=renew_ad&id="+self.myAdModelArray[index].id!)
      print("Print mail",userDefault.string(forKey: "email")!, "Print password", userDefault.string(forKey: "password")!)
      let currentDate = Date()
      let currentDateFormatter = DateFormatter()
      currentDateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
      self.myAdModelArray[index].date_posted = currentDateFormatter.string(from: currentDate)
      let parameters : Parameters = ["email": "ivica@gmail.com", "password":"123456", "date_posted": self.myAdModelArray[index].date_updated!]
      //userDefailt.synchronize()
      /*
       let dateFormatterPublishedOn = DateFormatter()
       dateFormatterPublishedOn.dateFormat = "yyyy.MM.dd HH:mm:ss"
       let datePublishedOn = dateFormatterPublishedOn.date(from: (myAdModelArray[indexPath.row].date_posted)!)
       dateFormatterPublishedOn.dateFormat = "dd.MM.YYYY"
       let newFormatPublishOn = dateFormatterPublishedOn.string(from: datePublishedOn!)
       */
      
      
      var uploadNewPublishOn : [String: String] = [:]
      Alamofire.request(API_URL_RENEW_AD!, method: .post, parameters: parameters as [String: AnyObject]).responseJSON
        { (response) in
          let responseAnswer = response
          /*
           if let result = response.result.value {
           let jsonData = result as! NSDictionary
           */
         if let responseResult = response.result.value
         {
          let jsonData = responseResult as! NSDictionary
          
          print("Print Response",jsonData.value(forKey: "message")!)
          let currentDate = Date()
          let currentDateFormatter = DateFormatter()
          currentDateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
          self.myAdModelArray[index].date_updated = currentDateFormatter.string(from: currentDate)
          }
          
          //print("Print response", response)


          self.myAdsTableView.reloadData()
     
//     for (key, value) in uploadNewPublishOn
//     {
//      value = currentDateFormatter.string(from: currentDate)
//      }
      
      }
//      self.myAdsTableView.reloadData()
      /*
       Alamofire.upload(
       15         multipartFormData: { multipartFormData in
       16             // On the PHP side you can retrive the image using $_FILES["image"]["tmp_name"]
       17             multipartFormData.append(imageToUploadURL!, withName: "image")
       18             for (key, val) in parameters {
       19                 multipartFormData.append(val.data(using: String.Encoding.utf8)!, withName: key)
       20             }
       21     },
       22         to: url,
       23         encodingCompletion: { encodingResult in
       24             switch encodingResult {
       25             case .success(let upload, _, _):
       26                 upload.responseJSON { response in
       27                     if let jsonResponse = response.result.value as? [String: Any] {
       28                         print(jsonResponse)
       29                     }
       30                 }
       31             case .failure(let encodingError):
       32                 print(encodingError)
       33             }
       34     }
       35     )
       */
      //var data = self.myAdModelArray[index].date_posted
      
//      Alamofire.upload(multipartFormData: { (multipartFormData) in
//        multipartFormData.append(data, withName: "date_posted")
//      }, to: API_URL_RENEW_AD!, encodingCompletion: { (encodingResults) in
//        switch encodingResults {
//        case.success(let uploda, _, _):
//          upload.responseJSON {
//            (response) in
//            if let jsonResponse = response.result.value as? [String: Any] {
//              print(jsonResponse)
//            }
//          }
//        case.failure(let encodingError):
//          print(encodingError)
//        }
//      })

//      Alamofire.request(API_URL_RENEW_AD!, method: .post, parameters: parameters).response {
//        response in
//        var responseArray = response as! [String: AnyObject]
//        print(responseArray["date_posted"])
//      }
    }
    self.myAdsTableView.reloadData()
  }
  
  
  @IBOutlet weak var myAdsTableView: UITableView!

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
      
    }
   func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
  {
    var credits = UILabel()
    credits.text = "You Have: 5000 Credits"
    return credits.text!
  }
}
extension MyAdsViewController {
  
  func alert(message: String, title: String = "") {
    let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
    let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
    alertController.addAction(OKAction)
    self.present(alertController, animated: true, completion: nil)
  }
  
}

