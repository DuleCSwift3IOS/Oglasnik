//
//  ForgotPasswordViewController.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 7/24/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField
import Alamofire
class ForgotPasswordViewController: UIViewController {

  var enterEmail: UITextField!
  var accepterMessage: String? = ""
  var errorMessage: String? = ""
  var timer: Timer?
  var delay = 5
    override func viewDidLoad() {
        super.viewDidLoad()
      let emailTextField = SkyFloatingLabelTextFieldWithIcon(frame: CGRect(x: 16, y: 206, width: 375, height: 45), iconType: .image)
      emailTextField.placeholder = "E-mail"
      emailTextField.title = "Enter E-mail:"
      
      emailTextField.tintColor = UIColor(red: 0, green: 187/255, blue: 204/255, alpha: 1.0)
      emailTextField.selectedTitleColor = UIColor(red: 0, green: 187/255, blue: 204/255, alpha: 1.0)
      emailTextField.selectedLineColor = UIColor(red: 0, green: 187/255, blue: 204/255, alpha: 1.0)
      
      // Set icon properties
      emailTextField.iconColor = UIColor.lightGray
      emailTextField.selectedIconColor = UIColor(red: 0, green: 187/255, blue: 204/255, alpha: 1.0)
      emailTextField.iconFont = UIFont(name: "FontAwesome", size: 15)
      emailTextField.iconImage = UIImage(imageLiteralResourceName: "user_registration")
      //"\u{f072}" // plane icon as per https://fortawesome.github.io/Font-Awesome/cheatsheet/
      emailTextField.iconMarginBottom = 4.0 // more precise icon positioning.
      emailTextField.iconMarginLeft = 4.0
      enterEmail = emailTextField
      self.view.addSubview(emailTextField)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  @objc func goHomeVC()
  {
    let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
    let goHomeVC = storyBoard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
    self.navigationController?.pushViewController(goHomeVC, animated: true)
  }
  
  @IBAction func sendAction(_ sender: Any) {
    print(enterEmail.text!)
    var API_URL_FORGOT_PASSWORD = URL(string: "https://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=forgot_password&email=\(enterEmail.text!)")
    var parameters: Parameters = ["email": enterEmail.text!]
    
    
      Alamofire.request(API_URL_FORGOT_PASSWORD!, method: .post, parameters: parameters, encoding: URLEncoding.default, headers: HTTPHeaders?.none).responseJSON { (response) in
         var results = response.result.value
         if let result = results
   {
            var backResult = result as! NSDictionary
            var resultMessage = backResult["message"] as! String
    
    if self.isValidEmail(testStr: (self.enterEmail?.text)!)
    {
      self.accepterMessage = resultMessage
    let attributeString = NSMutableAttributedString(string: self.accepterMessage!, attributes: [NSAttributedStringKey.font : UIFont.systemFont(ofSize: 20), NSAttributedStringKey.foregroundColor: UIColor.white])
        let alertMessage = UIAlertController(title: "", message: "", preferredStyle: .alert)
        alertMessage.setValue(attributeString, forKey: "attributedTitle")
        self.present(alertMessage, animated: true, completion: nil)
        let when = DispatchTime.now() + 4
        DispatchQueue.main.asyncAfter(deadline: when, execute: {
          alertMessage.dismiss(animated: true, completion: nil)
          alertMessage.accessibilityActivate()
          let subview = (alertMessage.view.subviews.first?.subviews.first?.subviews.first!)! as UIView
          subview.layer.cornerRadius = 5
          subview.backgroundColor = UIColor.green
          self.timer?.invalidate()
          self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(self.delay), target: self, selector: #selector(self.goHomeVC), userInfo: nil, repeats: false)
    })
  }
    
 }
}
}
  func isValidEmail(testStr:String) -> Bool {
    // print("validate calendar: \(testStr)")
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    
    let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
    return emailTest.evaluate(with: testStr)
  }
  @objc func backToSameVC()
  {
    self.navigationController?.popToRootViewController(animated: true)
  }
}


