//
//  MyAdsCell.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 10/23/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import UIKit

class MyAdsCell: UITableViewCell {

  @IBOutlet weak var checkedAndUnCheckedButton: UIButton!
  @IBOutlet weak var editButton: UIButton!
  @IBOutlet weak var myAdImageView: UIImageView!
  @IBOutlet weak var myAdInfoStackView: UIStackView!
  @IBOutlet weak var myAdTitleLabel: UILabel!
  @IBOutlet weak var myAdPublishedLabel: UILabel!
  @IBOutlet weak var myAdPublishDateLabel: UILabel!
  @IBOutlet weak var myAdPriceLabel: UILabel!
  @IBOutlet weak var myAdPriceAndValuteLabel: UILabel!
  @IBOutlet weak var myAdViewLabel: UILabel!
  @IBOutlet weak var myAdNumberOfViewLabel: UILabel!
  override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
