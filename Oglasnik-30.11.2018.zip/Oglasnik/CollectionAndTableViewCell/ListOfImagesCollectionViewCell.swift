//
//  ListOfImagesCollectionViewCell.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 7/30/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import UIKit

class ListOfImagesCollectionViewCell: UICollectionViewCell {
    
  @IBOutlet weak var detailIMGListImage: UIImageView!
}
