//
//  MenuViewController.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 2/7/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import UIKit
import Kingfisher
class MenuViewController: UIViewController {
  
  @IBOutlet weak var homeImageView: UIImageView!
  @IBOutlet weak var addAdsButton: UIButton!
  @IBOutlet weak var autosImage: UIImageView!
  @IBOutlet weak var autosButton: UIButton!
  @IBOutlet weak var mobilesButton: UIButton!
  @IBOutlet weak var electronicsButton: UIButton!
  @IBOutlet weak var realEstateButton: UIButton!
  @IBOutlet weak var petsButton: UIButton!
  @IBOutlet weak var fashionButton: UIButton!
  @IBOutlet weak var jobButton: UIButton!
  @IBOutlet weak var allAdsButton: UIButton!
  var listOfAds: ListTableViewController?
  var goToAdsController : Bool = true
  
  @IBAction func showListOFAdsActionButton(_ sender: UIButton) {
    if sender.tag == 1
    {
      var catNo = "3"
      let listOfAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
      listOfAdsViewController.catAds = catNo
      let navigationController = UINavigationController(rootViewController: listOfAdsViewController)
      
      self.present(navigationController, animated: true, completion: nil)
     //present(listOfAds!, animated: true, completion: nil)
      
      print("Autos")
      //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getAds&cat=3
    }
    if sender.tag == 2
    {
      var catNo = "10"
      let listOfAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
      listOfAdsViewController.catAds = catNo
      let navigationController = UINavigationController(rootViewController: listOfAdsViewController)
      
      self.present(navigationController, animated: true, completion: nil)
      print("Mobiles")
      //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getAds&cat=10
    }
    if sender.tag == 3
    {
      var catNo = "9"
      let listOfAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
      listOfAdsViewController.catAds = catNo
      let navigationController = UINavigationController(rootViewController: listOfAdsViewController)
      
      self.present(navigationController, animated: true, completion: nil)
      print("Electronic")
      //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getAds&cat=9
    }
    if sender.tag == 4
    {
      var catNo = "16"
      let listOfAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
      listOfAdsViewController.catAds = catNo
      let navigationController = UINavigationController(rootViewController: listOfAdsViewController)
      
      self.present(navigationController, animated: true, completion: nil)
      print("Real Estate")
      //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getAds&cat=16
    }
    if sender.tag == 5
    {
      var catNo = "25"
      let listOfAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
      listOfAdsViewController.catAds = catNo
      let navigationController = UINavigationController(rootViewController: listOfAdsViewController)
      
      self.present(navigationController, animated: true, completion: nil)
      print("Real Estate")
      //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getAds&cat=25
    }
    if sender.tag == 6
    {
      var catNo = "42"
      let listOfAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
      listOfAdsViewController.catAds = catNo
      let navigationController = UINavigationController(rootViewController: listOfAdsViewController)
      
      self.present(navigationController, animated: true, completion: nil)
      print("Fashion")
      //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getAds&cat=42
    }
    if sender.tag == 7
    {
      var catNo = "57"
      let listOfAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
      listOfAdsViewController.catAds = catNo
      let navigationController = UINavigationController(rootViewController: listOfAdsViewController)
      
      self.present(navigationController, animated: true, completion: nil)
      print("Job")
      //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getAds&cat=57
    }
    if sender.tag == 8
    {
      var catNo = ""
      let listOfAdsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListTableViewController") as! ListTableViewController
      listOfAdsViewController.catAds = catNo
      let navigationController = UINavigationController(rootViewController: listOfAdsViewController)
      
      self.present(navigationController, animated: true, completion: nil)
      print("All Ads")
      //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getAds
    }
  }
  
  
    override func viewDidLoad() {
        super.viewDidLoad()
      
//      if autosButton.tag == 1
//      {
      var homePage_URL = URL(string: "https://media.angieslist.com/s3fs-public/styles/widescreen_large/public/fea_realestateapps_0315_house-phone.jpg?itok=2JhgY9an")
//        print("Autos")
      self.homeImageView.kf.setImage(with: homePage_URL)
      homeImageView.contentMode = .scaleAspectFill
//        //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getCategories
//      }
//      if mobilesButton.tag == 2
//      {
//        print("Mobiles")
//        //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getCategories
//      }
//      if electronicsButton.tag == 3
//      {
//        print("Electronic")
//        //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getCategories
//      }
//      if realEstateButton.tag == 4
//      {
//        print("Real Estate")
//        //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getCategories
//      }
//      if petsButton.tag == 5
//      {
//        print("Real Estate")
//        //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getCategories
//      }
//      if fashionButton.tag == 6
//      {
//        print("Fashion")
//        //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getCategories
//      }
//      if jobButton.tag == 7
//      {
//        print("Job")
//        //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getCategories
//      }
//      if allAdsButton.tag == 8
//      {
//        print("All Ads")
//        //http://bilbord.mk/api.php?key=3g5fg3f5gf2h32k2j&function=getCategories
//      }
      //BUTTON FOR ADD MESSAGE DON'T REMOVE
//      let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped(gesture:)))
//      autosImage.addGestureRecognizer(tapGesture)
//      addAdsButton.layer.shadowColor = UIColor.blue.cgColor
//      addAdsButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
//      addAdsButton.layer.shadowRadius = 1.0
//      addAdsButton.layer.shadowOpacity = 0.5
//      autosImage.isUserInteractionEnabled = true
//      addAdsButton.layer.masksToBounds = false
//      addAdsButton.layer.cornerRadius = addAdsButton.frame.width / 2
        // Do any additional setup after loading the view.
//      // Shadow and Radius for Circle Button
//      myBtn.layer.shadowColor = UIColor.black.cgColor
//      myBtn.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
//      myBtn.layer.masksToBounds = false
//      myBtn.layer.shadowRadius = 1.0
//      myBtn.layer.shadowOpacity = 0.5
//      myBtn.layer.cornerRadius = myBtn.frame.width / 2
    }

  @IBAction func publishAdAction(_ sender: Any) {
    performSegue(withIdentifier: "actionAdSegue", sender: self)
  }
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "actionAdSegue"
    {
      
      let adsDestionationViewController = segue.destination as! AddNewAdsViewController
      adsDestionationViewController.backToRootViewController = goToAdsController
//      self.present(adsDestionationViewController, animated: true, completion: nil)
    }
  }
  @objc func imageTapped(gesture: UIGestureRecognizer)
  {
    print("image Tapped")
   // self.autosImage.backgroundColor = UIColor.blue
    
  }
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  @IBAction func leftSideButtonTapped(_ sender: Any) {
    var appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
    appDelegate.centerContainer!.toggle(MMDrawerSide.left, animated: true, completion: nil)
  }
/*
   // create tap gesture recognizer
   let tapGesture = UITapGestureRecognizer(target: self, action: #selector(ViewController.imageTapped(gesture:)))
   
   // add it to the image view;
   imageView.addGestureRecognizer(tapGesture)
   // make sure imageView can be interacted with by user
   imageView.isUserInteractionEnabled = true
   }
   
   func imageTapped(gesture: UIGestureRecognizer) {
   // if the tapped view is a UIImageView then set it to imageview
   if (gesture.view as? UIImageView) != nil {
   print("Image Tapped")
   //Here you can initiate your new ViewController
   
   }
*/
}
