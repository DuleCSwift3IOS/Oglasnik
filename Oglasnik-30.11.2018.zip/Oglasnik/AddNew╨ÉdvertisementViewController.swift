//
//  AddNewАdvertisementViewController.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 1/15/18.
//  Copyright © 2018 Big Nerd Ranch. All rights reserved.
//

import UIKit
import BEMCheckBox
class AddNew_dvertisementViewController: UIViewController, UITextFieldDelegate {

  
  override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

 

}
