//
//  oglasnikView.swift
//  Oglasnik
//
//  Created by Dushko Cizaloski on 11/10/17.
//  Copyright © 2017 Big Nerd Ranch. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {
  static let oglasnikColorBackground = UIColor(red: 2, green: 175, blue: 200, alpha: 0.5)
}
